import conversion as MAC 
import Adder as Add

def BinaryAdder():
    print("Welcome to Binary World")
    half = False 
    while half == False:
        full = False 
        while full == False:
            try:
                x = int(input("Enter First Number: ")) 
               
                cin = 0
                if x > 255 or x < 0:
                    print("LOL !! Next time enter Number between 0 and 255")
                else:
                    full = True
            except:
                print("ERROR !! Please Correct your value") 
        full = False
        while full == False:
            try:
                y = int(input("Enter Second Number: "))
                if y > 255 or y<0:
                    print("LOL !! Next time enter Number between 0 and 255")
                else:
                    full = True
            except:
                print("ERROR !! Please Correct your value") 
        BinaryX = MAC.decimalToBinary(x) 
        BinaryY = MAC.decimalToBinary(y) 
        print(f"Binary Value of 1st number: {BinaryX}")
        print(f"Binary Value of 2nd Number: {BinaryY}")
        value = ""
        value = Add.byte_adder(str(BinaryX),str(BinaryY),cin) 
        print(f"Sum: {value}")
        exe = input("Continue to program click enter/ press EXIT to kill your program:  ") 
        exe = exe.upper()
        if exe == "EXIT":
            half = True
            print("Now you are in the open battleground !!")

            
BinaryAdder() #calling Binary function 

