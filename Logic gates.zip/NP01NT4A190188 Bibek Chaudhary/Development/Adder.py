import Gate as gate

def byte_adder(a, b, cin):
    output = ""

    for i in range(len(b)-1,-1,-1): 
        fs = gate.xor_Gate(int(a[i]),int(b[i]))
        sum_val = gate.xor_Gate(fs, cin)
        output += str(sum_val)
        
        fco = gate.and_Gate(int(a[i]),int(b[i]))
        fco2 = gate.and_Gate(fs,cin)
        co = gate.or_Gate(fco, fco2)
        cin = co
    
    if cin == 1:
        output += str(cin)
    output = output[::-1] 

    return output
