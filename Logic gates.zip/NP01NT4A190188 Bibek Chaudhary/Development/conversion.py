#Conversion of Binary to decimal and decimal to binary
def binaryToDecimal(Binary):
    decimalValue = 0
    initial = 1
    for i in range(len(Binary)-1,-1,-1):
        decimalValue = decimalValue + initial*Binary[i]
        initial = initial*2
    return decimalValue 
def decimalToBinary(n):
    temp = []
    Binary = ""
    while n > 0:
        if n%2 != 0:
            temp.append(1) 
        else:
            temp.append(0) 
        n = int(n/2) 
    for i in range(len(temp)-1,-1,-1):
        Binary += str(temp[i])
    if len(Binary) < 8:
        for i in range(len(Binary),8):
            Binary = "0" + Binary    
    return Binary 
